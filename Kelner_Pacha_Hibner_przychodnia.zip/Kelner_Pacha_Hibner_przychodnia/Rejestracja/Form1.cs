﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Rejestracja.DAL;

namespace Rejestracja
{
    using DAL;
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
            rejestracja1.SelectedDoctorChanged += Rejestracja1_SelectedDoctorChanged;
        }

        private void Rejestracja1_SelectedDoctorChanged(Doctor doctor)
        {
            rejestracja1.ListWizyty = VisitRepository.GetVisits(doctor).ToArray();
        }

        private void rejestracja1_Load(object sender, EventArgs e)
        {
            
            try
            {
                var doc = DoctorsRepository.GetAllDoctors();
                //var wiz = VisitRepository.GetAllVisit();
                var pes = PeselRepository.GetAllPesel();


                

                foreach (var d in doc)
                    Console.WriteLine(d);
                rejestracja1.ListLekarzy = doc.ToArray();

                //foreach (var w in wiz)
                //    Console.WriteLine(w);
                //rejestracja1.ListWizyty = wiz.ToArray();
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
            //foreach (var p in pes)
            //    Console.WriteLine(p);
            //rejestracja1.ListPesele = pes.ToArray();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void rejestracja1_Load_1(object sender, EventArgs e)
        {

        }

        //private void rejestracja1_Load_1(object sender, EventArgs e)
        //{

        //}
    }
}
