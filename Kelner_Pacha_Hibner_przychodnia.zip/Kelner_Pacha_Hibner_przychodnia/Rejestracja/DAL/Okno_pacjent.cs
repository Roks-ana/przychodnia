﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rejestracja.DAL
{
    public partial class Okno_pacjent : Form
    {
        public Okno_pacjent() {
            InitializeComponent();
            LoadPatients();

        }

        private void LoadPatients() {
            Lista.Items.Clear();
            List<Patient> tempList = PatientsRepository.GetPatients();
            foreach (var patient in tempList) {
                Lista.Items.Add(patient);
            }
        }

        private void imie_TextChanged(object sender, EventArgs e)
        {

        }
  
        private void button2_Click(object sender, EventArgs e)
        {
            Patient patient = new Patient(imie.Text, nazwisko.Text, pesel.Text, nr_tel.Text, data.Text);
            PatientsRepository repository = new PatientsRepository();
            Console.Write($" Data to : {patient.BirthdayDate}");
            repository.DodajPacjenta(patient);
            Console.WriteLine("Dodalo pacjenta");
            Lista.Items.Add(patient);


        
            pesel.Clear();
            nr_tel.Clear();
            imie.Clear();
            nazwisko.Clear();
            data.ResetText();
            
            }

        private void Lista_SelectedIndexChanged(object sender, EventArgs e) {
            Patient p = (Patient)Lista.Items[Lista.SelectedIndex];
            imie.Text = p.FirstNameP;
            nazwisko.Text = p.LastNameP;
            nr_tel.Text = p.NrTel;
            pesel.Text = p.ID;
            data.Text = p.BirthdayDate;
            
        }
        //Usuwanie pacjentów
        private void button3_Click(object sender, EventArgs e) {
            if (Lista.SelectedIndex < 0) {
                MessageBox.Show("Wybierz osobę z listy do edycji");
            } else {
                PatientsRepository patientsRepository = new PatientsRepository();
                Patient p = (Patient)Lista.Items[Lista.SelectedIndex];
                patientsRepository.DeletePatient(p.ID);
                LoadPatients();
            }
        }
        //Edycja pacjentów
        private void button1_Click(object sender, EventArgs e) {
            if (Lista.SelectedIndex < 0) {
                MessageBox.Show("Wybierz osobę z listy do edycji");
            } else {


                PatientsRepository patientsRepository = new PatientsRepository();
                Patient p = (Patient)Lista.Items[Lista.SelectedIndex];
                p.FirstNameP = imie.Text;
                p.LastNameP = nazwisko.Text;
                p.NrTel = nr_tel.Text;
                p.BirthdayDate = data.Text;
                patientsRepository.UpdatePatient(p);
                LoadPatients();
            }
        }
    }
    }

