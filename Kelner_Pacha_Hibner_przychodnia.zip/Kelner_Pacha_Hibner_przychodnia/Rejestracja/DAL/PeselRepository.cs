﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Rejestracja.DAL
{
    class PeselRepository
    {

        private static string SELECT_P = " SELECT  pesel  FROM `wizyta`";

        public static List<Pesel> GetAllPesel()
        {
            List<Pesel> pesele = new List<Pesel>();
            using (var conn = DBConnection.Instance.Connection)
            {
                conn.Open();
                using (MySqlCommand command = new MySqlCommand(SELECT_P, conn))
                {
                    MySqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        pesele.Add(new Pesel(reader));
                    }

                }



            }


            return pesele;
        }
    }
}
