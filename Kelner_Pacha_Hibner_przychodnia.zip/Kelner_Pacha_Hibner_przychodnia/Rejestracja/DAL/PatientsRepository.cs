﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Rejestracja.DAL
{
    public class PatientsRepository {




        public void DodajPacjenta(Patient user) {

            string name = user.FirstNameP;
            string surname = user.LastNameP;
            string pesel = user.ID;
            string telephone = user.NrTel;
            string data = user.BirthdayDate;

            Console.Write($" Data to : {data}");
            using (var conn = DBConnection.Instance.Connection) {
                try {
                    conn.Open();

                    using (MySqlCommand command = new MySqlCommand($"INSERT INTO pacjenci VALUES( '{pesel}', '{name}', '{surname}', '{telephone}', '{data}')", conn)) {
                        command.ExecuteNonQuery();
                        // user.FirstNameP = "";
                        // user.LastNameP = "";
                        // user.ID = "";
                        // user.NrTel = "";
                    }
                    conn.Close();
                    MessageBox.Show("Dodano pacjenta");
                } catch (Exception exc) {
                    Console.WriteLine("ERROR: " + exc.Message);
                }

            }



        }

        public int getAmountOfPatientByPesel(string pesel) {
           
            int counter = 0;
            try {
                using (var conn = DBConnection.Instance.Connection) {
                    conn.Open();
                    using (MySqlCommand command = new MySqlCommand($"SELECT * FROM pacjenci WHERE pesel like '{pesel}'", conn)) {
                        MySqlDataReader reader = command.ExecuteReader();
                        while (reader.Read()) {
                            counter++;
                        }

                    }

                    conn.Close();

                }
                return counter;
            } catch (Exception exp) {
                Console.WriteLine(exp.Message);
                return 0;
            } 

        }
        public static List<Patient> GetPatients() {
            List<Patient> pacjenci = new List<Patient>();
            using (var conn = DBConnection.Instance.Connection) {
                conn.Open();
                using (MySqlCommand command = new MySqlCommand("SELECT * FROM pacjenci", conn)) {
                    MySqlDataReader reader = command.ExecuteReader();
                    while (reader.Read()) {
                        pacjenci.Add(new Patient(reader));
                    }

                }



            }


            return pacjenci;
        }

        public void UpdatePatient(Patient patient)
        {
            using (var conn = DBConnection.Instance.Connection)
            {
                try
                {
                    conn.Open();

                    using (MySqlCommand command = new MySqlCommand($"UPDATE pacjenci SET imie='{patient.FirstNameP}',nazwisko='{patient.LastNameP}',telefon='{patient.NrTel}',data_urodzenia='{patient.BirthdayDate}' WHERE pesel = '{patient.ID}'", conn))
                    {
                        command.ExecuteNonQuery();

                    }
                    conn.Close();
                    MessageBox.Show("Zaaktualizowano  pacjenta");
                }
                catch (Exception exc)
                {
                    Console.WriteLine("ERROR: " + exc.Message);
                }

            }
        }

       

        public void DeletePatient(string pesel) {
            using (var conn = DBConnection.Instance.Connection) {
                try {
                    conn.Open();

                    using (MySqlCommand command = new MySqlCommand($"DELETE FROM `pacjenci` WHERE pesel = '{pesel}'", conn)) {
                        command.ExecuteNonQuery();
                   
                    }
                    conn.Close();
                    MessageBox.Show("Usunięto pacjenta");
                } catch (Exception exc) {
                    Console.WriteLine("ERROR: " + exc.Message);
                }

            }
        }

    }
    
}
